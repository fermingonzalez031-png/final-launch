type TwilioClient = {
  messages: {
    create: (opts: { body: string; from: string; to: string }) => Promise<void>
  }
}

function getTwilioClient(): TwilioClient | null {
  if (!process.env.TWILIO_ACCOUNT_SID || !process.env.TWILIO_AUTH_TOKEN) return null
  try {
    // Twilio is a CommonJS module - dynamic import used at runtime only
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const twilio = require('twilio') as (sid: string, token: string) => TwilioClient
    return twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  } catch {
    return null
  }
}

export async function sendSMS(to: string, body: string): Promise<boolean> {
  const client = getTwilioClient()
  if (!client) {
    console.log(`[SMS SKIPPED] To: ${to} | Body: ${body}`)
    return false
  }
  try {
    await client.messages.create({ body, from: process.env.TWILIO_FROM_NUMBER ?? '', to })
    return true
  } catch (err) {
    console.error('[SMS ERROR]', err)
    return false
  }
}

export function buildOrderSMS(type: string, orderNumber: string, extra = ''): string {
  const msgs: Record<string, string> = {
    new_request:        `New Prodrop request ${orderNumber}. ${extra}`,
    supplier_confirmed: `Part confirmed for order ${orderNumber}. Driver being assigned. ${extra}`,
    driver_assigned:    `Driver assigned for order ${orderNumber}. ${extra}`,
    picked_up:          `Your part has been picked up for order ${orderNumber}. ${extra}`,
    en_route:           `Driver en route for order ${orderNumber}. ${extra}`,
    delivered:          `Order ${orderNumber} delivered! ${extra}`,
    issue:              `Issue with order ${orderNumber}. Our dispatcher is on it. ${extra}`,
  }
  return msgs[type] ?? `Order ${orderNumber} status update. ${extra}`
}
